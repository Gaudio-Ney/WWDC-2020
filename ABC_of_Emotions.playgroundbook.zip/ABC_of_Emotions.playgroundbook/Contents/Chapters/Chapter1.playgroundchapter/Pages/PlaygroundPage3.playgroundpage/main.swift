/*:
 ![Banner](Thanks.png)
 # Thanks!

 You completed the Playground experience!

 Yes, it was brief but I really expect that you have had the opportunity to know more about your own emotions in different kinds of situations. Personally, I am enchanted by the way code and technology can help us in many different ways, from a simple representation of the mood meter from the RULER method to a real app that impacts millions of lives worldwide.

 Thanks!!! And bye bye! 🥳✌️
 
 Oh, do not forget to click on the button to celebrate because you deserve it!
 
 # Credits
 
 Research used:
 
 * RULER: Yale Center for Emotions Intelligence, © Emotionally Intelligent Schools, LLC.
 
 */
